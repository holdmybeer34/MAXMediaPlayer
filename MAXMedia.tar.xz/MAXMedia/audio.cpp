#include "objects.hpp"
#include <alsa/asoundlib.h>
#include <thread>
#include <cstdlib>

#define MINIMP3_IMPLEMENTATION
#include "minimp3.hpp"
#include "minimp3_ex.hpp"

AudioPlayer::AudioPlayer(QObject* parent) : QObject(parent){}

void AudioPlayer::play(const QString& path){
    std::thread([path](){
        mp3dec_t mp3d;
        mp3dec_file_info_t info{};
        mp3dec_init(&mp3d);
        mp3dec_load(&mp3d, path.toStdString().c_str(), &info, nullptr, nullptr);
        
        snd_pcm_t* pcm = nullptr;
        snd_pcm_open(&pcm, "default", SND_PCM_STREAM_PLAYBACK, 0);

        snd_pcm_hw_params_t* hw;
        snd_pcm_hw_params_alloca(&hw);
        snd_pcm_hw_params_any(pcm, hw);
        snd_pcm_hw_params_set_access(pcm, hw, SND_PCM_ACCESS_RW_INTERLEAVED);
        snd_pcm_hw_params_set_format(pcm, hw, SND_PCM_FORMAT_S16_LE);

        unsigned int rate = info.hz;
        snd_pcm_hw_params_set_rate_near(pcm, hw, &rate, 0);
        snd_pcm_hw_params_set_channels(pcm, hw, info.channels);
        snd_pcm_hw_params(pcm, hw);

        snd_pcm_writei(pcm, info.buffer, info.samples / info.channels);

        snd_pcm_drain(pcm);
        snd_pcm_close(pcm);
        free(info.buffer);
    }).detach();
}