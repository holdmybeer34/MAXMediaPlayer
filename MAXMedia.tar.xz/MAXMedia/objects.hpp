#pragma once
#include <QMainWindow>
#include <QPushButton>
#include <QObject>
#include <QString>

class AudioPlayer : public QObject {
    Q_OBJECT

    public:
    explicit AudioPlayer(QObject* parent = nullptr);

    void play(const QString& path);
};

class PlayButton : public QPushButton {
    Q_OBJECT

    public:
    explicit PlayButton(QWidget* parent = nullptr);
};

class MainWindow : public QMainWindow {
    Q_OBJECT

    public:
    explicit MainWindow(QWidget* parent = nullptr);

    private slots:
    void onPlayClicked();

    private:
    PlayButton* play;
    AudioPlayer* player;
};